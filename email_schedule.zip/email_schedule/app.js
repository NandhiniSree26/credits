const nodemailer = require('nodemailer');
const cron = require('node-cron');
// email message option 
const mailOptions = {
    from: 'harshinandhu26@gmail.com',
    to : 'harshinandhu26@gmail.com',
    subject: 'Daily Notification',
 
    
};
function sendDailyEmail() {
    // Get the form data from wherever you store it (e.g., a database)
    // Replace the following line with your code to retrieve the form data
    const formData = {
      name: 'Nandhu',
      mobile: '987654321',
      email: 'Nandhu@gmail.com',
      dob: '1997-01-01',
      address: '123 Main Street'
    };}
const transporter = nodemailer.createTransport({
    service: 'gmail', // Replace with your email service provider (e.g., Gmail, Outlook)
    auth: {
      user: 'harshi@gmail.com', // Replace with your email address
      pass: 'suja@1234' // Replace with your email password
    }
  });
  // send email

//   cron.schedule('* * * * *' , () => {
//     console.log('email send')
//   })

//    cron.schedule('* * * * * ', () => {
    transporter.sendMail(mailOptions,(error, info)=> {
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });

//    })
 

// Schedule the email trigger at 10:00 AM every day
function scheduleEmailTrigger() {
    const now = new Date();
    const scheduledTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 10, 0, 0); // Set to 10:00 AM
    let timeUntilTrigger = scheduledTime - now;
  
    if (timeUntilTrigger < 0) {
      scheduledTime.setDate(scheduledTime.getDate() + 1); // Schedule for the next day if current time has already passed 10:00 AM
      timeUntilTrigger = scheduledTime - now;
    }
  
    setTimeout(sendDailyEmail, timeUntilTrigger);
  }
  
  // Start the email trigger scheduling
  scheduleEmailTrigger();